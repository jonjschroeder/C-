
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
 
namespace YourNamespace.Controllers
{
    public class HelloController : Controller
    {
        [HttpGet]
        [Route("/{FirstName}/{LastName}/{Age}/{FavColour}")]
        public JsonResult CallCard(string FirstName, string LastName, string Age, string FavColour)
{
        return Json(new {FirstName = FirstName, LastName = LastName, Age = Age, FavColour = FavColour});
}
}
}