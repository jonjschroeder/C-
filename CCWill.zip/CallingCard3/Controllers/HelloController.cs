using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;



namespace YourNamespace.Controllers
{
    public class HelloController : Controller
    {
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {

            //OR
            return View("Index");
            //Both of these returns will render the same view (You only need one!)
        }
        [HttpGet]
        [Route("/project")]
        public IActionResult Project()
        {

            //OR
            return View("Project");
            //Both of these returns will render the same view (You only need one!)
        }
                [HttpGet]
                [Route("contact")]
                public IActionResult Contact()
        {

            //OR
            return View("Contact");
            //Both of these returns will render the same view (You only need one!)
        }
                [HttpPost]
                [Route("/result")]
                public IActionResult dispaly(string firstname, string lastname, string comment)
                
        {

            //OR
            ViewBag.fname = firstname;
            ViewBag.lname = lastname;
            ViewBag.com = comment;
            return View("display");
            //Both of these returns will render the same view (You only need one!)

        }
    }
}