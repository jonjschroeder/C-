using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using subway.Models;

namespace subway.Controllers
{
    public class HomeController : Controller
    {
        private readonly DbConnector _dbConnector;
 
        public HomeController(DbConnector connect)
        {
            _dbConnector = connect;
        }
        
        // GET: /Home/
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            ViewBag.Users = _dbConnector.Query("SELECT * FROM Users");
            ViewBag.Errors = new List<string>();
            return View();
        }   
        [HttpPost]
        [Route("")]
        public IActionResult Login()
        {
            ViewBag.Users = _dbConnector.Query("SELECT * FROM Users");
            ViewBag.Errors = new List<string>();
            return View("Index");
        } 
        [HttpPost]
        [Route("Register")]
        public IActionResult Register(User NewUser)
        {

            TryValidateModel(NewUser);
            if(ModelState.IsValid){
                return View("success");
            }
            ViewBag.errors = ModelState.Values;
            return View("Index");
            
        }     

    }
}
